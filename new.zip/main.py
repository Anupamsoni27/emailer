import csv
import datetime
import json
import smtplib, ssl, email
from email import encoders
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import pandas as pd


class Emailer():

    def __init__(self, emailTemplate):
            self.subject = emailTemplate["subject"]
            self.body = emailTemplate["body"]
            self.attachments_path = emailTemplate["attachment_folder_path"]
            self.user_email = emailTemplate["setting_email"]
            self.user_password = emailTemplate["setting_password"]
            self.attachment_files = []
            for root, dir, files in os.walk(self.attachments_path):
                for file in files:
                    self.attachment_files.append(root + os.sep + file)

            # self.attachment_files = emailTemplate["attachment_folder_path"]

    def send_mail(self, target_email):
        try:
            sender_email = self.user_email
            receiver_email = target_email
            password = self.user_password

            # Create MIMEMultipart object
            msg = MIMEMultipart("alternative")
            msg["Subject"] = self.subject
            msg["From"] = sender_email
            msg["To"] = receiver_email
            filenames = self.attachment_files

            # HTML Message Part
            # html = """\
            # <html>
            #   <body>
            #     <p><b>Python Mail Test</b>
            #     <br>
            #        This is HTML email with attachment.<br>
            #        Click on <a href="https://fedingo.com">Fedingo Resources</a>
            #        for more python articles.
            #     </p>
            #   </body>
            # </html>
            # """
            html = self.body
            part = MIMEText(html, "html")
            msg.attach(part)

            # Add Attachment
            for filename in filenames:
                with open(filename, "rb") as attachment:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(attachment.read())

                    encoders.encode_base64(part)

                    # Set mail headers
                    part.add_header(
                        "Content-Disposition",
                        "attachment", filename=filename
                    )
                    msg.attach(part)

            # Create secure SMTP connection and send email
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL("mail.dhirtekbusinessresearch.com", 465, context=context) as server:
                server.login(sender_email, password)
                server.sendmail(
                    sender_email, receiver_email, msg.as_string()
                )
            return True
        except:
            return False



email_template = "email_template.csv"
email_list = "email_list.csv"

def remove_email_from_target_file(value):
    old_file_list = []
    new_file_list = []
    with open(email_list) as em_file:
        reader = csv.reader(em_file)
        for row in reader:
            old_file_list.append(row)
        for old_file_list_row in old_file_list:
            if not value in old_file_list_row:
                new_file_list.append(row)
    with open(email_list,"w",newline="") as new_file:
        new_writer = csv.writer(new_file)
        new_writer.writerows(new_file_list)

with open(email_list) as flat_file:
    reader = csv.reader(flat_file)
    target_email_list = [row[0] for row in reader if len(row)>0 if "@" in row[0]]

success_folder = "results/success/" + datetime.datetime.now().__str__().split(" ")[0].replace("-", "")
failure_folder = "results/failure/" + datetime.datetime.now().__str__().split(" ")[0].replace("-", "")
try:
    os.mkdir(success_folder)
except:
    pass

try:
    os.mkdir(failure_folder)
except:
    pass
# with open(email_template) as f:
#     emailTemplate = json.load(f)

def get_template(path):
    df = pd.read_csv(path,nrows=1)
    if df.shape.__str__() == '(1, 5)':
        emailTemplate = {
            "subject": df["subject"][0],
            "body": df["body"][0],
            "attachment_folder_path": df["attachment_folder_path"][0],
            "setting_email": df["setting_email"][0],
            "setting_password": df["setting_password"][0]
        }
        return emailTemplate
    print("################################ ERROR ##################################")
    print("email_template.csv should have only 1 row and 5 columns.")
    print("##################################################################")


emailer = Emailer(emailTemplate=get_template(email_template))
for email in target_email_list:
    if emailer.send_mail(email):
        with open(success_folder + os.sep + "list.csv","a",newline="") as sf:
            writer = csv.writer(sf)
            writer.writerow([email])
            remove_email_from_target_file(value=email)
    elif emailer.send_mail(email) is False:
        with open(failure_folder + os.sep + "list.csv","a",newline="") as ff:
            writer = csv.writer(ff)
            writer.writerow([email])
    break
